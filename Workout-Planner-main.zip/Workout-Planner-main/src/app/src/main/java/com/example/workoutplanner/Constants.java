package com.example.workoutplanner;

public class Constants {
    public static final String EXERCISE_EXTRA = "exercise";
    public static final String ROUTINE_EXTRA = "routine";
    public static final String ROUTINE_EXERCISE_EXTRA = "routineExercise";
}
